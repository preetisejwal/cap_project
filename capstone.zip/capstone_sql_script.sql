-- Total number of completed offers.
SELECT COUNT(*) AS total_completed_offers
FROM events_N
WHERE event = 'offer completed';

/* total number of offer completed is :33182*/

-- completion rate for each offer type*/
WITH received_offers AS (
    SELECT 
        e.offer_ids,
        o.offer_type,
        COUNT(*) AS received_count
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer received'
    GROUP BY e.offer_ids, o.offer_type
),
completed_offers AS (
    SELECT 
        e.offer_ids,
        o.offer_type,
        COUNT(*) AS completed_count
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer completed'
    GROUP BY e.offer_ids, o.offer_type
)
SELECT 
    r.offer_type,
    SUM(r.received_count) AS received_count,
    COALESCE(SUM(c.completed_count), 0) AS completed_count,
    COALESCE((SUM(c.completed_count) * 100.0) / NULLIF(SUM(r.received_count), 0), 0) AS completion_rate
FROM received_offers r
LEFT JOIN completed_offers c ON r.offer_ids = c.offer_ids
GROUP BY r.offer_type;


/*SELECT 
    o.offer_type,
	sum(CASE WHEN e.event = 'offer received' THEN 1 ELSE 0 END) AS total_received,
    SUM(CASE WHEN e.event = 'offer completed' THEN 1 ELSE 0 END) AS total_completed,
    (SUM(CASE WHEN e.event = 'offer completed' THEN 1 ELSE 0 END) * 100.0 / 
     NULLIF(sum(CASE WHEN e.event = 'offer received' THEN 1 ELSE 0 END),0)) AS completion_rate
FROM events_c1 e
JOIN offers o ON TRIM(e.offer_id) = TRIM(o.offer_id) -- Ensuring IDs match even with extra spaces
WHERE e.event IN ('offer received', 'offer completed') -- Ensuring only relevant events are included
GROUP BY o.offer_type;*/

/*bogo	30499	15501	50.82462
discount	30543	17681	57.88888
informational	15235	0	0.00000*/

-- Identify offers with the highest and lowest success rates
WITH received_offers AS (
    SELECT 
        e.offer_ids,
        o.offer_type,
        COUNT(*) AS received_count
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer received'
    GROUP BY e.offer_ids, o.offer_type
),
completed_offers AS (
    SELECT 
        e.offer_ids,
        o.offer_type,
        COUNT(*) AS completed_count
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer completed'
    GROUP BY e.offer_ids, o.offer_type
),
offer_success_rates AS (
    SELECT 
        r.offer_ids,
        r.offer_type,
        r.received_count,
        COALESCE(c.completed_count, 0) AS completed_count,
        COALESCE((c.completed_count * 100.0) / NULLIF(r.received_count, 0), 0) AS success_rate
    FROM received_offers r
    LEFT JOIN completed_offers c ON r.offer_ids = c.offer_ids
)
SELECT * FROM offer_success_rates
WHERE success_rate = (SELECT MAX(success_rate) FROM offer_success_rates)
   OR success_rate = (SELECT MIN(success_rate) FROM offer_success_rates);

/*Analyze the distribution of demographic attributes:
Age group, income, gender, and location.*/
-- Age Group Distribution
SELECT 
    CASE 
        WHEN age BETWEEN 18 AND 24 THEN '18-24'
        WHEN age BETWEEN 25 AND 34 THEN '25-34'
        WHEN age BETWEEN 35 AND 44 THEN '35-44'
        WHEN age BETWEEN 45 AND 54 THEN '45-54'
        WHEN age BETWEEN 55 AND 64 THEN '55-64'
        ELSE '65+'
    END AS age_group,
    COUNT(*) AS count
FROM customers1
GROUP BY age_group
ORDER BY age_group;

-- Income Distribution
SELECT 
    CASE 
        WHEN income < 30000 THEN 'Under 30K'
        WHEN income BETWEEN 30000 AND 49999 THEN '30K-50K'
        WHEN income BETWEEN 50000 AND 74999 THEN '50K-75K'
        WHEN income BETWEEN 75000 AND 99999 THEN '75K-100K'
        WHEN income BETWEEN 100000 AND 149999 THEN '100K-150K'
        ELSE '150K+'
    END AS income_group,
    COUNT(*) AS count
FROM customers1
GROUP BY income_group
ORDER BY income_group;

-- Gender Distribution
SELECT gender, COUNT(*) AS count
FROM customers1
GROUP BY gender
ORDER BY count DESC;

-- Link these attributes to offer completion rates.
WITH age_groups AS (
    SELECT 
        customer_id,
        gender,
        income,
        CASE 
            WHEN age BETWEEN 18 AND 24 THEN '18-24'
            WHEN age BETWEEN 25 AND 34 THEN '25-34'
            WHEN age BETWEEN 35 AND 44 THEN '35-44'
            WHEN age BETWEEN 45 AND 54 THEN '45-54'
            WHEN age BETWEEN 55 AND 64 THEN '55-64'
            ELSE '65+'
        END AS age_group
    FROM customers1
),

income_distribution AS (
    SELECT 
        customer_id,
        CASE 
            WHEN income < 30000 THEN 'Low Income (<30K)'
            WHEN income BETWEEN 30000 AND 60000 THEN 'Middle Income (30K-60K)'
            WHEN income BETWEEN 60000 AND 100000 THEN 'Upper Middle Income (60K-100K)'
            ELSE 'High Income (>100K)'
        END AS income_category
    FROM customers1
),

-- Received Offers by Demographic Attributes
received_offers AS (
    SELECT 
        c.customer_id,
        a.age_group,
        i.income_category,
        c.gender,
        COUNT(*) AS received_count
    FROM events_N e
    JOIN customers1 c ON e.customer_id = c.customer_id
    JOIN age_groups a ON c.customer_id = a.customer_id
    JOIN income_distribution i ON c.customer_id = i.customer_id
    WHERE e.event = 'offer received'
    GROUP BY c.customer_id, a.age_group, i.income_category, c.gender
),

-- Completed Offers by Demographic Attributes
completed_offers AS (
    SELECT 
        c.customer_id,
        a.age_group,
        i.income_category,
        c.gender,
        COUNT(*) AS completed_count
    FROM events_N e
    JOIN customers1 c ON e.customer_id = c.customer_id
    JOIN age_groups a ON c.customer_id = a.customer_id
    JOIN income_distribution i ON c.customer_id = i.customer_id
    WHERE e.event = 'offer completed'
    GROUP BY c.customer_id, a.age_group, i.income_category, c.gender
)
use rewardsnext;
-- Linking Demographics to Offer Completion Rates
SELECT 
    r.age_group,
    r.income_category,
    r.gender,
    SUM(r.received_count) AS total_received,
    COALESCE(SUM(c.completed_count), 0) AS total_completed,
    COALESCE((SUM(c.completed_count) * 100.0) / NULLIF(SUM(r.received_count), 0), 0) AS completion_rate
FROM received_offers r
LEFT JOIN completed_offers c 
    ON r.customer_id = c.customer_id
GROUP BY r.age_group, r.income_category, r.gender;

-- Average transaction per customer


SELECT 
    COUNT(*) / COUNT(DISTINCT customer_id) AS avg_transactions_per_customer
FROM events_n
WHERE event = 'transaction';
-- 8

/*Daily transaction volumes and their correlation with active offers.*/

WITH daily_transactions AS (
    SELECT 
        FLOOR(time / 24) AS day_number,  -- Convert hours to day number
        COUNT(*) AS transaction_count
    FROM events_N
    WHERE event = 'transaction'
    GROUP BY FLOOR(time / 24)
),

active_offers AS (
    SELECT 
        FLOOR(time / 24) AS day_number,
        COUNT(DISTINCT offer_ids) AS active_offers
    FROM events_N
    WHERE event = 'offer received'
    GROUP BY FLOOR(time / 24)
)

SELECT 
    d.day_number,
    d.transaction_count,
    COALESCE(a.active_offers, 0) AS active_offers
FROM daily_transactions d
LEFT JOIN active_offers a 
    ON d.day_number = a.day_number
ORDER BY d.day_number;

/*Identify how many informational offers directly resulted in transactions.*/

WITH informational_offers AS (
    SELECT 
        e.customer_id,
        e.offer_ids,
        e.time AS offer_received_time
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer received' 
      AND o.offer_type = 'informational'
),

transactions_after_offer AS (
    SELECT 
        t.customer_id,
        t.time AS transaction_time
    FROM events_N t
    WHERE t.event = 'transaction'
)

SELECT 
    COUNT(DISTINCT t.customer_id) AS customers_with_transactions,
    COUNT(*) AS total_transactions
FROM informational_offers io
JOIN transactions_after_offer t 
    ON io.customer_id = t.customer_id
    AND t.transaction_time >= io.offer_received_time;

/*o	Calculate the average time between offer reception and redemption.*/
SELECT 
    AVG(completed.time - received.time) AS avg_time_to_redeem
FROM events_N received
JOIN events_N completed 
    ON received.customer_id = completed.customer_id
    AND received.offer_ids = completed.offer_ids
    AND completed.time >= received.time
WHERE received.event = 'offer received'
AND completed.event = 'offer completed';


/*SEGMENT CUSTOMERS AS PER PREFERED OFFER TYPE */
 WITH offer_engagement AS (
    SELECT 
        e.customer_id,
        o.offer_type,
        COUNT(*) AS engagement_count
    FROM events_N e
    JOIN offers o ON e.offer_ids = o.offer_id
    WHERE e.event = 'offer completed'
    GROUP BY e.customer_id, o.offer_type
),

ranked_offers AS (
    SELECT 
        customer_id,
        offer_type,
        engagement_count,
        RANK() OVER (PARTITION BY customer_id ORDER BY engagement_count DESC) AS rank_order
    FROM offer_engagement
)

SELECT 
    customer_id,
    offer_type AS preferred_offer_type
FROM ranked_offers
WHERE rank_order = 1;

 
  /*	Group customers into segments based on their transaction behavior:*/
 WITH transaction_counts AS (
    SELECT 
        customer_id,
        COUNT(*) AS transaction_count
    FROM events_N
    WHERE event = 'transaction'
    GROUP BY customer_id
)

SELECT 
    customer_id,
    transaction_count,
    CASE 
        WHEN transaction_count >= 20 THEN 'Frequent Buyer'
        WHEN transaction_count BETWEEN 5 AND 19 THEN 'Occasional Buyer'
        ELSE 'Dormant Customer'
    END AS customer_segment
FROM transaction_counts;
